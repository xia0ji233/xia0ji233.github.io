#include<ntifs.h> 
#include <ntddk.h>
#include <ntstrsafe.h>

#define kprintf(format, ...) DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, format, ##__VA_ARGS__)
#define MAX_BACKTRACE_DEPTH 20
ULONG64 num = 0;
NTSTATUS EnumerateKernelThreads();

typedef NTSTATUS (*ZWQUERYSYSTEMINFORMATION)(ULONG, PVOID, ULONG, PULONG);

VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	kprintf(("unload\n"));

}


NTSTATUS EnumerateKernelThreads() {


    PETHREAD T12 = NULL;
    PETHREAD T;
    PsLookupThreadByThreadId(12, &T12);
    kprintf(("T12=%p\n"), T12);
    ULONG64 Start = *(ULONG64 *)((ULONG64)T12 + 0x620);
    HANDLE TargetThread = 0;
    for (int i = 16; i < 0x20000; i+=4) {
        T = NULL;
        PsLookupThreadByThreadId(i, &T);
        if (T) {
            ULONG64 Startaddr = *(ULONG64 *)((ULONG64)T + 0x620);
            if (Startaddr == Start) {
                kprintf(("Found Thread=%p pThread=%p\n"), i,T);
         
                TargetThread = i;
                break;
            }
           
        }
    }


    if (T != NULL) {
        ULONG64 ExitTime = NULL;
        while (!ExitTime) {
            ExitTime=*(ULONG64 *)((ULONG64)T + 0x608);
            LARGE_INTEGER inTime;
            inTime.QuadPart = 1000 * -10000;
            KeDelayExecutionThread(KernelMode, FALSE, &inTime);
        }

        ULONG64 address;
        for (ULONG64 i = 0x0; i <65536; i++)
        {
            address = ExitTime & 0xffffffff00000000;
            address = address + 0x1000;
            address = address + (i<<16);
            if (MmIsAddressValid((PVOID)address) && *((ULONG64 *)address) == 0x7C8B483024748B48 )
            {
                kprintf(("shellcode found in %p\n"), address);
                //DbgBreakPoint();
                break;
            }

        }
        
    }


    return STATUS_SUCCESS;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
    
	kprintf(("hello xia0ji233\n"));

    EnumerateKernelThreads();
	pDriver->DriverUnload = DRIVERUNLOAD;
	return STATUS_SUCCESS;
}