#include<ntifs.h> 
#include <ntddk.h>
#include <ntstrsafe.h>
#include <ntimage.h>

#define kprintf(format, ...) DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, format, ##__VA_ARGS__)
#define MAX_BACKTRACE_DEPTH 20
ULONG64 num = 0;
NTSTATUS EnumerateKernelThreads();

typedef NTSTATUS(NTAPI* PPsSuspendThread)(IN PETHREAD Thread, OUT PULONG PreviousSuspendCount OPTIONAL);

PPsSuspendThread g_PsSuspendThread = NULL;
typedef struct _KLDR_DATA_TABLE_ENTRY
{
	LIST_ENTRY InLoadOrderLinks;
	PVOID ExceptionTable;
	ULONG ExceptionTableSize;
	PVOID GpValue;
	ULONG UnKnow;
	PVOID DllBase;
	PVOID EntryPoint;
	ULONG SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
	ULONG Flags;
	USHORT LoadCount;
	USHORT __Unused5;
	PVOID SectionPointer;
	ULONG CheckSum;
	PVOID LoadedImports;
	PVOID PatchInformation;
} KLDR_DATA_TABLE_ENTRY, *PKLDR_DATA_TABLE_ENTRY;



VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	kprintf(("unload\n"));

}


PVOID SearchOPcode(PDRIVER_OBJECT pObj, PWCHAR DriverName, PCHAR sectionName, PUCHAR opCode, int len, int offset)
{
	PVOID dllBase = NULL;
	UNICODE_STRING uniDriverName;
	PKLDR_DATA_TABLE_ENTRY firstentry;

	// ��ȡ�������
	PKLDR_DATA_TABLE_ENTRY entry = (PKLDR_DATA_TABLE_ENTRY)pObj->DriverSection;

	firstentry = entry;
	RtlInitUnicodeString(&uniDriverName, DriverName);

	// ��ʼ����
	while ((PKLDR_DATA_TABLE_ENTRY)entry->InLoadOrderLinks.Flink != firstentry)
	{
		// ����ҵ�������ģ���������ַ����
		if (entry->FullDllName.Buffer != 0 && entry->BaseDllName.Buffer != 0)
		{
			if (RtlCompareUnicodeString(&uniDriverName, &(entry->BaseDllName), FALSE) == 0)
			{
				dllBase = entry->DllBase;
				break;
			}
		}
		entry = (PKLDR_DATA_TABLE_ENTRY)entry->InLoadOrderLinks.Flink;
	}

	if (dllBase)
	{
		__try
		{
			// ����ģ�����ַ
			PIMAGE_DOS_HEADER ImageDosHeader = (PIMAGE_DOS_HEADER)dllBase;
			if (ImageDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
			{
				return NULL;
			}
			// �õ�ģ��NTͷ
			PIMAGE_NT_HEADERS64 pImageNtHeaders64 = (PIMAGE_NT_HEADERS64)((PUCHAR)dllBase + ImageDosHeader->e_lfanew);

			// ��ȡ�ڱ�ͷ
			PIMAGE_SECTION_HEADER pSectionHeader = (PIMAGE_SECTION_HEADER)((PUCHAR)pImageNtHeaders64 + sizeof(pImageNtHeaders64->Signature) + sizeof(pImageNtHeaders64->FileHeader) + pImageNtHeaders64->FileHeader.SizeOfOptionalHeader);

			PUCHAR endAddress = 0;
			PUCHAR starAddress = 0;

			// Ѱ�ҷ��������Ľ�
			for (int i = 0; i < pImageNtHeaders64->FileHeader.NumberOfSections; i++)
			{
				// Ѱ�ҷ��������ı���
				if (memcmp(sectionName, pSectionHeader->Name, strlen(sectionName) + 1) == 0)
				{
					// ȡ����ʼ�ͽ�����ַ
					starAddress = pSectionHeader->VirtualAddress + (PUCHAR)dllBase;
					endAddress = pSectionHeader->VirtualAddress + (PUCHAR)dllBase + pSectionHeader->SizeOfRawData;
					break;
				}
				// ������һ����
				pSectionHeader++;
			}
			if (endAddress && starAddress)
			{
				// �ҵ��ῪʼѰ������
				for (; starAddress < endAddress - len - 1; starAddress++)
				{
					// ��֤����Ȩ��
					if (MmIsAddressValid(starAddress))
					{
						int i = 0;
						for (; i < len; i++)
						{
							// �ж��Ƿ�Ϊͨ���'*'
							if (opCode[i] == 0x2a)
								continue;

							// �ҵ���һ���ֽ�������
							if (opCode[i] != starAddress[i])
								break;
						}
						// �ҵ�������ȫƥ���򷵻ص�ַ
						if (i == len)
						{
							return starAddress + offset;
						}
					}
				}
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}
	}

	return NULL;
}

ULONG64 get_a_valid_addr_in_shellcode(PETHREAD pThread)
{
	ULONG64 initStackAddr = *(PULONG64)((PUCHAR)pThread + 0x28);
	PKTRAP_FRAME ptrap = (PKTRAP_FRAME)(initStackAddr - sizeof(KTRAP_FRAME));
	return ptrap->ExceptionFrame;
}



NTSTATUS EnumerateKernelThreads() {


    PETHREAD T12 = NULL;
    PETHREAD T;
    PsLookupThreadByThreadId(12, &T12);
    kprintf(("T12=%p\n"), T12);
    ULONG64 Start = *(ULONG64 *)((ULONG64)T12 + 0x620);
    HANDLE TargetThread = 0;
    for (int i = 16; i < 0x20000; i+=4) {
        T = NULL;
        PsLookupThreadByThreadId(i, &T);
        if (T) {
            ULONG64 Startaddr = *(ULONG64 *)((ULONG64)T + 0x620);
            if (Startaddr == Start) {
                kprintf(("Found Thread=%p pThread=%p\n"), i,T);
         
                TargetThread = i;
                break;
            }
           
        }
    }
	if (T) {
		ULONG64 StackBase = 0;
        ULONG64 StackLimit = 0;
        StackBase= *(ULONG64 *)((ULONG64)T + 0x38);
        StackLimit=*(ULONG64 *)((ULONG64)T + 0x30);
        kprintf(("Stackbase=%p StackLimit=%p\n"), StackBase, StackLimit);
		PVOID threadObj = NULL;
		NTSTATUS state = ObReferenceObjectByHandle(TargetThread, 0x1FFFFF, *PsThreadType, KernelMode, &threadObj, NULL);
		g_PsSuspendThread(threadObj, NULL);

		for (ULONG64 addr = StackBase - 0x10 - sizeof(KTRAP_FRAME); addr > StackLimit; addr -= 8) {
			

			KTRAP_FRAME* ptr = addr;
			if (ptr->Rsp == addr) {
				kprintf(("shellcode found in %p\n"), ptr->Rip);
				break;
			}
		}

	}
    





    return STATUS_SUCCESS;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
    
	kprintf(("hello xia0ji233\n"));
    UCHAR SuspendOpCode[] = { 0x48, 0x8b, 0xf9, 0x83, 0x64, 0x24, 0x20, 0x00, 0x65, 0x48, 0x8b, 0x34, 0x25, 0x88, 0x01 };
    g_PsSuspendThread = (PPsSuspendThread)SearchOPcode(pDriver, L"ntoskrnl.exe", "PAGE", SuspendOpCode, sizeof(SuspendOpCode), -24);

    EnumerateKernelThreads();
	pDriver->DriverUnload = DRIVERUNLOAD;
	return STATUS_SUCCESS;
}