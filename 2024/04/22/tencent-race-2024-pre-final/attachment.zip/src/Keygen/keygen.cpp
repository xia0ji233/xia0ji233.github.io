#include<stdio.h>
#include<string.h>
int main(){
	char user[]="xia0ji233";
	int n=strlen(user);
	unsigned key=0;
	for(int i=0;i<n;i++){
		key=(key+user[i])*0x1003F;
	}
	printf("%u\n",key);
}
