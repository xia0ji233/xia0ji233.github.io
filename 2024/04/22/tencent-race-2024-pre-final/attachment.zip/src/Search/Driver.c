#include "vad.h"
#include <ntifs.h>
#define kprintf(format, ...) DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, format, ##__VA_ARGS__)
// ����VAD�����EProcessͷ��ƫ��ֵ
#define eprocess_offset_VadRoot 0x7d8
#define eprocess_offset_VadCount 0x7e8

VOID EnumVad(PMMVAD Root, PALL_VADS pBuffer, ULONG nCnt)
{
    if (!Root || !pBuffer || !nCnt)
    {
        return;
    }

    __try
    {
        if (nCnt > pBuffer->nCnt)
        {
            // �õ���ʼҳ�����ҳ
            ULONG64 endptr = (ULONG64)Root->Core.EndingVpnHigh;
            endptr = endptr << 32;

            ULONG64 startptr = (ULONG64)Root->Core.StartingVpnHigh;
            startptr = startptr << 32;

            // �õ����ڵ�
            pBuffer->VadInfos[pBuffer->nCnt].pVad = (ULONG_PTR)Root;

            // ��ʼҳ: startingVpn * 0x1000
            pBuffer->VadInfos[pBuffer->nCnt].startVpn = (startptr | Root->Core.StartingVpn) << PAGE_SHIFT;

            // ����ҳ: EndVpn * 0x1000 + 0xfff
            pBuffer->VadInfos[pBuffer->nCnt].endVpn = ((endptr | Root->Core.EndingVpn) << PAGE_SHIFT) + 0xfff;

            // VAD��־ 928 = Mapped    1049088 = Private   ....
            pBuffer->VadInfos[pBuffer->nCnt].flags = Root->Core.u1.Flags.flag;

            // ��֤�ڵ�ɶ���
            if (MmIsAddressValid(Root->Subsection) && MmIsAddressValid(Root->Subsection->ControlArea))
            {
                if (MmIsAddressValid((PVOID)((Root->Subsection->ControlArea->FilePointer.Value >> 4) << 4)))
                {
                    pBuffer->VadInfos[pBuffer->nCnt].pFileObject = ((Root->Subsection->ControlArea->FilePointer.Value >> 4) << 4);
                }
            }
            pBuffer->nCnt++;
        }

        if (MmIsAddressValid(Root->Core.VadNode.Left))
        {
            // �ݹ�ö��������
            EnumVad((PMMVAD)Root->Core.VadNode.Left, pBuffer, nCnt);
        }

        if (MmIsAddressValid(Root->Core.VadNode.Right))
        {
            // �ݹ�ö��������
            EnumVad((PMMVAD)Root->Core.VadNode.Right, pBuffer, nCnt);
        }
    }
    __except (1)
    {
    }
}

BOOLEAN EnumProcessVad(ULONG Pid, PALL_VADS pBuffer, ULONG nCnt)
{
    PEPROCESS Peprocess = 0;
    PRTL_AVL_TREE Table = NULL;
    PMMVAD Root = NULL;

    // ͨ������PID�õ�����EProcess
    if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)Pid, &Peprocess)))
    {
        // ��ƫ����ӵõ�VADͷ�ڵ�
        Table = (PRTL_AVL_TREE)((UCHAR*)Peprocess + eprocess_offset_VadRoot);
        if (!MmIsAddressValid(Table) || !eprocess_offset_VadRoot)
        {
            return FALSE;
        }

        __try
        {
            // ȡ��ͷ�ڵ�
            Root = (PMMVAD)Table->Root;

            if (nCnt > pBuffer->nCnt)
            {
                // �õ���ʼҳ�����ҳ
                ULONG64 endptr = (ULONG64)Root->Core.EndingVpnHigh;
                endptr = endptr << 32;

                ULONG64 startptr = (ULONG64)Root->Core.StartingVpnHigh;
                startptr = startptr << 32;

                pBuffer->VadInfos[pBuffer->nCnt].pVad = (ULONG_PTR)Root;

                // ��ʼҳ: startingVpn * 0x1000
                pBuffer->VadInfos[pBuffer->nCnt].startVpn = (startptr | Root->Core.StartingVpn) << PAGE_SHIFT;

                // ����ҳ: EndVpn * 0x1000 + 0xfff
                pBuffer->VadInfos[pBuffer->nCnt].endVpn = (endptr | Root->Core.EndingVpn) << PAGE_SHIFT;
                pBuffer->VadInfos[pBuffer->nCnt].flags = Root->Core.u1.Flags.flag;

                if (MmIsAddressValid(Root->Subsection) && MmIsAddressValid(Root->Subsection->ControlArea))
                {
                    if (MmIsAddressValid((PVOID)((Root->Subsection->ControlArea->FilePointer.Value >> 4) << 4)))
                    {
                        pBuffer->VadInfos[pBuffer->nCnt].pFileObject = ((Root->Subsection->ControlArea->FilePointer.Value >> 4) << 4);
                    }
                }
                pBuffer->nCnt++;
            }

            // ö��������
            if (Table->Root->Left)
            {
                EnumVad((MMVAD*)Table->Root->Left, pBuffer, nCnt);
            }

            // ö��������
            if (Table->Root->Right)
            {
                EnumVad((MMVAD*)Table->Root->Right, pBuffer, nCnt);
            }
        }
        __finally
        {
            ObDereferenceObject(Peprocess);
        }
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

VOID UnDriver(PDRIVER_OBJECT driver)
{
    kprintf(("unload\n"));
}

NTSTATUS DriverEntry(IN PDRIVER_OBJECT Driver, PUNICODE_STRING RegistryPath)
{
    kprintf(("hello xia0ji233\n"));

    typedef struct
    {
        ULONG nPid;
        ULONG nSize;
        PALL_VADS pBuffer;
    }VADProcess;

    __try
    {
        VADProcess vad = { 0 };

        vad.nPid = 4;

        // Ĭ����1000���߳�
        vad.nSize = sizeof(VAD_INFO) * 0x5000 + sizeof(ULONG);

        // ������ʱ�ռ�
        vad.pBuffer = (PALL_VADS)ExAllocatePool(PagedPool, vad.nSize);

        // ���ݴ��볤�ȵõ�ö������
        ULONG nCount = (vad.nSize - sizeof(ULONG)) / sizeof(VAD_INFO);

        // ö��VAD
        EnumProcessVad(vad.nPid, vad.pBuffer, nCount);
        
        uintptr_t start_address = vad.pBuffer->VadInfos[0].pVad & 0xffffffff00000000;
        start_address = start_address + 0x1000;



        for (ULONG64 i = 0x0; i <65536; i++)
        {
            start_address = vad.pBuffer->VadInfos[0].pVad & 0xffffffff00000000;
            start_address = start_address + 0x1000;
            start_address = start_address + (i<<16);
            if (MmIsAddressValid((PVOID)start_address) && *((unsigned *)start_address) == 0x24748B48 )
            {
                kprintf(("shellcode found in %p\n"), start_address);
                //DbgBreakPoint();
                goto end;
            }

        }
        kprintf(("Shellcode Not Found"));
    }
    __except (1)

    {
        kprintf(("Something Error\n"));
    }
end:
    Driver->DriverUnload = UnDriver;
    return STATUS_SUCCESS;
}