// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "pch.h"
#include<Windows.h>
#include<stdio.h>
#include<TlHelp32.h>

typedef enum _THREADINFOCLASS{
    ThreadBasicInformation,
    ThreadTimes,
    ThreadPriority,
    ThreadBasePriority,
    ThreadAffinityMask,
    ThreadImpersonationToken,
    ThreadDescriptorTableEntry,
    ThreadEnableAlignmentFaultFixup,
    ThreadEventPair_Reusable,
    ThreadQuerySetWin32StartAddress,
    ThreadZeroTlsCell,
    ThreadPerformanceCount,
    ThreadAmILastThread,
    ThreadIdealProcessor,
    ThreadPriorityBoost,
    ThreadSetTlsArrayAddress,
    ThreadIsIoPending,
    ThreadHideFromDebugger,
    ThreadBreakOnTermination,
    MaxThreadInfoClass
}THREADINFOCLASS;
typedef struct _CLIENT_ID{
    HANDLE UniqueProcess;
    HANDLE UniqueThread;
}CLIENT_ID;
typedef struct _THREAD_BASIC_INFORMATION{
    LONG ExitStatus;
    PVOID TebBaseAddress;
    CLIENT_ID ClientId;
    LONG AffinityMask;
    LONG Priority;
    LONG BasePriority;
}THREAD_BASIC_INFORMATION,*PTHREAD_BASIC_INFORMATION;
extern "C" LONG (__stdcall *ZwQueryInformationThread)(
    IN HANDLE ThreadHandle,
    IN THREADINFOCLASS ThreadInformationClass,
    OUT PVOID ThreadInformation,
    IN ULONG ThreadInformationLength,
    OUT PULONG ReturnLength OPTIONAL
    ) = NULL;

BYTE CODE[] = {
    0x40,0x53,0x48,0x83,0xEC,0x20,0x48,0x8B,0xD9,0x48,0x85,0xC9
};
BOOL hack() {
    

    HANDLE hThreadSnap = INVALID_HANDLE_VALUE; 
    THREADENTRY32 te32; 
    DWORD dwOwnerPID = GetCurrentProcessId();
    hThreadSnap = CreateToolhelp32Snapshot( TH32CS_SNAPTHREAD, 0 ); 
    if( hThreadSnap == INVALID_HANDLE_VALUE ) 
    return( FALSE ); 
    
    te32.dwSize = sizeof(THREADENTRY32 ); 
    if( !Thread32First( hThreadSnap, &te32 ) ) 
    {
        CloseHandle( hThreadSnap );     // Must clean up the snapshot object!
        return( FALSE );
    }
    ULONG64 StartAddress;
    DWORD dwReturnLength;
    
    
    
    do 
    { 
        if( te32.th32OwnerProcessID == dwOwnerPID )
        {
            
            if (te32.th32OwnerProcessID) {
                HANDLE hThread = OpenThread(THREAD_QUERY_INFORMATION, FALSE, te32.th32ThreadID);
                if (hThread != NULL) {
                    

                    HINSTANCE hNTDLL = GetModuleHandle(L"ntdll");
                    (FARPROC&)ZwQueryInformationThread  = ::GetProcAddress(hNTDLL,"ZwQueryInformationThread");
                    PVOID startaddr;						// 用来接收线程入口地址
					ZwQueryInformationThread(
						hThread,							// 线程句柄
						ThreadQuerySetWin32StartAddress,	// 线程信息类型，ThreadQuerySetWin32StartAddress ：线程入口地址
						&startaddr,							// 指向缓冲区的指针
						sizeof(startaddr),					// 缓冲区的大小
						NULL								
						);


                    if (!memcmp(startaddr,CODE,sizeof(CODE))) {
                        char msg[0x50];
                        sprintf(msg, "Found the Shellcode in address:%p", startaddr);
                        MessageBoxA(NULL, msg, "Success", MB_OK);
                        sprintf(msg, "Replace The byte %02x to 0x01 in addr %p\n",*((BYTE*)startaddr - 0x5ddb + 4) ,(BYTE*)startaddr - 0x5ddb + 4);
                        MessageBoxA(NULL, msg, "Success", MB_OK);
                        *((BYTE*)startaddr - 0x5ddb + 4) = 1;
                        return TRUE;
                    }
                    CloseHandle(hThread);
                }
            }
        }
    } while( Thread32Next(hThreadSnap, &te32 ) );


    //  Don't forget to clean up the snapshot object.
    CloseHandle( hThreadSnap );
    return( FALSE );


}
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:

        if (!hack()) {
            MessageBoxA(NULL, "Fail", "FAIL", MB_OK);
        }
        else {
            MessageBoxA(NULL, "Success", "Success", MB_OK);
        }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

