#include <ntifs.h>
#include <ntdef.h>
#include <ntstatus.h>
#include <ntddk.h>

#define kprintf(format, ...) DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, format, ##__VA_ARGS__)
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);
VOID UnloadDriver(PDRIVER_OBJECT DriverObject);
NTSTATUS EnumerateKernelThreads();

typedef NTSTATUS (*ZWQUERYSYSTEMINFORMATION)(ULONG, PVOID, ULONG, PULONG);
typedef struct _SYSTEM_PROCESS_INFORMATION {
    ULONG NextEntryOffset;
    ULONG NumberOfThreads;
    LARGE_INTEGER Reserved[3];
    LARGE_INTEGER CreateTime;
    LARGE_INTEGER UserTime;
    LARGE_INTEGER KernelTime;
    UNICODE_STRING ImageName;
    ULONG BasePriority;
    HANDLE ProcessId;
    HANDLE InheritedFromProcessId;
} SYSTEM_PROCESS_INFORMATION, *PSYSTEM_PROCESS_INFORMATION;
typedef struct _SYSTEM_THREAD_INFORMATION {
    LARGE_INTEGER KernelTime;
    LARGE_INTEGER UserTime;
    LARGE_INTEGER CreateTime;
    ULONG WaitTime;
    PVOID StartAddress;
    CLIENT_ID ClientId;
    ULONG Priority;
    LONG BasePriority;
    ULONG ContextSwitchCount;
    LONG State;
    LONG WaitReason;
} SYSTEM_THREAD_INFORMATION, *PSYSTEM_THREAD_INFORMATION;
typedef enum _SYSTEM_INFORMATION_CLASS {
    SystemProcessInformation = 5
} SYSTEM_INFORMATION_CLASS;
#define SystemModuleInformation 11

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);
    DriverObject->DriverUnload = UnloadDriver;
    kprintf(("Driver Loaded\n"));
    return EnumerateKernelThreads();
}

VOID UnloadDriver(PDRIVER_OBJECT DriverObject) {
    UNREFERENCED_PARAMETER(DriverObject);
    kprintf(("Driver Unloaded\n"));
}

char CODE[]={
    0x48 ,0x8B ,0xC4 ,0x48 ,0x89 ,0x58 ,0x08 ,0x48 ,0x89 ,0x78 ,0x18 ,0x4C ,0x89 ,0x70 ,0x20 ,0x55,
    //0x48 ,0x8D ,0x68 ,0xA1 ,0x48 ,0x81 ,0xEC ,0xA0 ,0x00 ,0x00 ,0x00 ,0x48 ,0xBF ,0x4E ,0x93 ,0x32,
};

KIRQL WPOFFx64()
{
    KIRQL irql = KeRaiseIrqlToDpcLevel();
    UINT64 cr0 = __readcr0();
    cr0 &= 0xfffffffffffeffff;
    __writecr0(cr0);
    _disable();
    return irql;
}

void WPONx64(KIRQL irql)
{
    UINT64 cr0 = __readcr0();
    cr0 |= 0x10000;
    _enable();
    __writecr0(cr0);
    KeLowerIrql(irql);
}

MDLWriteMemory(PVOID pBaseAddress, PVOID pWriteData, SIZE_T writeDataSize)
{
    PMDL pMdl = NULL;
    PVOID pNewAddress = NULL;
    pMdl = MmCreateMdl(NULL, pBaseAddress, writeDataSize);
    if (NULL == pMdl)
    {
        return FALSE;
    }
    MmBuildMdlForNonPagedPool(pMdl);
    pNewAddress = MmMapLockedPages(pMdl, KernelMode);
    if (NULL == pNewAddress)
    {
        IoFreeMdl(pMdl);
    }
    RtlCopyMemory(pNewAddress, pWriteData, writeDataSize);
    MmUnmapLockedPages(pNewAddress, pMdl);
    IoFreeMdl(pMdl);
    return TRUE;
}

NTSTATUS EnumerateKernelThreads() {
    UNICODE_STRING routineName;
    RtlInitUnicodeString(&routineName, L"ZwQuerySystemInformation");
    ZWQUERYSYSTEMINFORMATION ZwQuerySystemInformation = (ZWQUERYSYSTEMINFORMATION)MmGetSystemRoutineAddress(&routineName);
    if (!ZwQuerySystemInformation) {
        return STATUS_UNSUCCESSFUL;
    }
    ULONG returnLength = 0;
    ZwQuerySystemInformation(SystemProcessInformation, NULL, 0, &returnLength);
    PVOID buffer = ExAllocatePool(NonPagedPool, returnLength);
    if (!buffer) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }
    NTSTATUS status = ZwQuerySystemInformation(SystemProcessInformation, buffer, returnLength, &returnLength);
    if (!NT_SUCCESS(status)) {
        ExFreePool(buffer);
        return status;
    }
    for (int k = 0; k < 1; k++) {
        PSYSTEM_PROCESS_INFORMATION current = (PSYSTEM_PROCESS_INFORMATION)buffer;
        while (TRUE) {
            PSYSTEM_THREAD_INFORMATION threadInfo = (PSYSTEM_THREAD_INFORMATION)(current + 1);
            for (ULONG i = 0; i < current->NumberOfThreads; i++) {

                if (((UINT64)(threadInfo->StartAddress) & 0xFFFFBB0000000000) == 0xFFFFBB0000000000) {
                    kprintf(("StartAddress %p\n"), threadInfo->StartAddress);
                
                    if (MmIsAddressValid(threadInfo->StartAddress) && RtlEqualMemory(threadInfo->StartAddress, CODE, sizeof(CODE))) {
                        kprintf(("Shellcode Found in %p\n"), threadInfo->StartAddress);
                        char* shellcode = threadInfo->StartAddress;
                        MDLWriteMemory(shellcode + 0x51 + 1, "\x00", 1);
                        MDLWriteMemory(shellcode + 0xb4 + 1, "\x00", 1);
                        MDLWriteMemory(shellcode + 0x124 + 1, "\x00", 1);
                    }
                }
                threadInfo++;
            }

            if (current->NextEntryOffset == 0)
                break;
        
            current = (PSYSTEM_PROCESS_INFORMATION)((PUCHAR)current + current->NextEntryOffset);
        }
    }

    ExFreePool(buffer);
    return STATUS_SUCCESS;
}
