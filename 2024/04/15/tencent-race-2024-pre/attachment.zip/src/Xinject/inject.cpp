﻿#include<windows.h>
#include<iostream>
#include<time.h>
#include<stdlib.h>
#include<TlHelp32.h>
#include <psapi.h>
#define PAGE_SIZE 0x1000
#define EXEFILEW L"hack.exe"
#define EXEFILE "hack.exe"
DWORD old;
SIZE_T written;
BYTE TMP[PAGE_SIZE];
DWORD FindProcess() {
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe32;
    pe32 = { sizeof(pe32) };
    BOOL ret = Process32First(hSnap, &pe32);
    while (ret)
    {
        if (!wcsncmp(pe32.szExeFile,  EXEFILEW, lstrlen(EXEFILEW))) {
            printf("找到程序 %s ,PID=%d\n", EXEFILE, pe32.th32ProcessID);
            return pe32.th32ProcessID;
        }
        ret = Process32Next(hSnap, &pe32);
    }
    return 0;
    CreateFileA;
    GENERIC_WRITE;
    CREATE_NEW;
}


BOOL DumpHeap( DWORD processID )
{
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processID);
    if (hProcess == NULL) {
        std::cerr << "Failed to open process. Error code: " << GetLastError() << std::endl;
        return 1;
    }

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPHEAPLIST, processID);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        std::cerr << "Failed to create snapshot. Error code: " << GetLastError() << std::endl;
        CloseHandle(hProcess);
        return 1;
    }

    HEAPLIST32 heapList;
    heapList.dwSize = sizeof(HEAPLIST32);
    if (!Heap32ListFirst(hSnapshot, &heapList)) {
        std::cerr << "Failed to retrieve first heap list entry. Error code: " << GetLastError() << std::endl;
        CloseHandle(hSnapshot);
        CloseHandle(hProcess);
        return 1;
    }

    FILE* outfile = fopen("hack.dump", "wb+");

    do {
        std::cout << "Heap addr: " <<std::hex<< heapList.th32HeapID << std::endl;
        MEMORY_BASIC_INFORMATION memInfo;
        SIZE_T dwSize = VirtualQueryEx(hProcess, (LPCVOID)heapList.th32HeapID, &memInfo, sizeof(memInfo));
        if (dwSize == 0) {
            std::cerr << "Failed to query memory. Error code: " << GetLastError() << std::endl;
            return 1;
        }

        for (INT64 i = heapList.th32HeapID; i < (INT64)heapList.th32HeapID + (INT64)memInfo.RegionSize; i += PAGE_SIZE) {
            ReadProcessMemory(hProcess, (LPCVOID)i, TMP, PAGE_SIZE,&written);
            fwrite(TMP, 1, PAGE_SIZE, outfile);
        }


    } while (Heap32ListNext(hSnapshot, &heapList));
    std::cout << "write file done" << std::endl;
    fclose(outfile);
    CloseHandle(hSnapshot);
    CloseHandle(hProcess);
    
    return 0;
}


void InjectModule(DWORD ProcessId, const char* szPath)
{
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcessId);
    printf("进程句柄:%p\n", hProcess);
    LPVOID lpAddress = VirtualAllocEx(hProcess, NULL, 0x100, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    SIZE_T dwWriteLength = 0;
    WriteProcessMemory(hProcess, lpAddress, szPath, strlen(szPath), &dwWriteLength);
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, NULL, (LPTHREAD_START_ROUTINE)LoadLibraryA, lpAddress, NULL, NULL);
    WaitForSingleObject(hThread, -1);
    VirtualFreeEx(hProcess, lpAddress, 0, MEM_RELEASE);
    CloseHandle(hProcess);
    CloseHandle(hThread);
}
int main() {
    DWORD ProcessId = FindProcess();
    while (!ProcessId) {
        printf("未找到%s程序，等待两毫秒中再试\n",EXEFILE);
        Sleep(2);
        ProcessId = FindProcess();
    }
    //DumpHeap(ProcessId);

    InjectModule(ProcessId, "hack.dll");
}