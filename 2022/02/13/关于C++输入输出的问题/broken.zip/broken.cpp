#include<bits/stdc++.h>
using namespace std;
signed main(){
	freopen("1.in","r",stdin);
	ios::sync_with_stdio(false);
	int q;
	cin>>q;
	while(q--){
		int s,t;
		scanf("%d %d",&s,&t);
		printf("s=%d t=%d\n",s,t); 
		
	}
	
	return 0;
}
