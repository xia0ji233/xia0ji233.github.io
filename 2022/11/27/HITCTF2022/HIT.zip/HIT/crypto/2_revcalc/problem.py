import string

p = 2**607 - 1


def s(a, b):
    return (a + b) % p

def u(a, b):
    return (a - b) % p

def m(a, b):
    return a * b % p

def scan(s):
    while s:
        if s[0] in string.ascii_letters:
            yield globals()[s[0]]
            s = s[1:]
        elif s[0] == '[':
            s = s[1:]
            num = s[:s.index(']')]
            yield int(num)
            s = s[len(num) + 1:]
        else:
            raise AssertionError

def calc(s):
    stack = []

    for token in scan(s):
        if type(token) == int:
            stack.append(token)
        else:
            b, a = stack.pop(), stack.pop()
            stack.append(token(a, b))
    
    assert len(stack) == 1
    return stack[0]

assert calc('[114514][1919810]s') == 2034324
assert calc('[114514][1919810]u') == 531137992816767098689588206552468627329593117727031923199444138200403559860852242739162502265229285668889329486246501015346579337652707239409519978766587351943831270835393219029922831
assert calc('[114514][1919810]m') == 219845122340
assert calc('[456][789][123]um') == 303696

from secret import flag
flag = int(flag.encode().hex(), base=16)
assert flag < p

cmd = open('cmd.txt', encoding='utf8').read()
cmd = cmd.replace('#', str(flag))
assert calc(cmd) == 211628186767393818556251909887187904577210135303836860239435739472106633529410929587038047765313010325750338075891823682635502490521440215978665151485743439682336190814184610992830040